# coding=utf-8
import os

from flask import Flask, render_template, request, redirect, url_for
from flask_uploads import UploadSet, IMAGES, configure_uploads, patch_request_class

app = Flask(__name__)
IMAGE_FOLDER = os.path.dirname(os.path.abspath(__file__)) + '/static/upload/'  # 文件上传的位置
app.config['UPLOADED_IMAGES_DEST'] = IMAGE_FOLDER

images = UploadSet('images', IMAGES)
configure_uploads(app, images)
patch_request_class(app)


@app.route('/')
@app.route('/photos')
def photos():
    images_ = []
    for root, dirs, files in os.walk(IMAGE_FOLDER):
        for file_ in files:
            images_.insert(0, '..\\static\\upload\\' + file_)
    return render_template('index.html', photos=images_)


@app.route('/upload_image', methods=['POST'])
def upload_image():
    files_ = request.files.getlist('file')
    for file_ in files_:
        images.save(file_)

    return 'Upload OK!'


@app.route('/upload')
def upload():
    return render_template('upload.html')


@app.route('/test')
def test():
    return 'OK'

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=True)
